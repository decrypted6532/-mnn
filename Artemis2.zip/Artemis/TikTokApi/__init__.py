"""
.. include:: ../README.md
"""
__docformat__ = "restructuredtext"

from TikTokApi.tiktok import TikTokApi
from TikTokApi.tiktokuser import TikTokUser
